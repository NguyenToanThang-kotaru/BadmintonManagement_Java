/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.managmentbadminton;
import GUI.GUI_Login;
/**
 *
 * @author Thang Nguyen
 */
public class ManagmentBadminton {

    public static void main(String[] args) {
        GUI_Login a = new GUI_Login();
        a.setVisible(true);
        System.out.print("avc");
    }
}
